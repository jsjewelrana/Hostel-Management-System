<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dropdown</title>
    <link rel="stylesheet" href="home.css" class="css">
    

</head>
<body>

    <div class="fullmain"> 

<div class="blank">
    
</div>

    <div class="waiver">
        <hr>
        <marquee direction="left">Admissions for 2022 is Open... Special Waiver Available for new customers only ...60% Special Waiver on Admission Fees ...
           <font color="green"> Online Admission Link:</font><a href="#"> admission.sadiaHostel.org.bd</a> ... 
           <font color="green">On-Hostel Admission:</font> Every day (10.00 am - 8.00 pm) ... 
           Hotline: 01533850435(10.00 am - 11.00 pm) ...Admissions for 2022 is Open... Special Waiver Available for new customers only ...60% Special Waiver on Admission Fees ...
           <font color="green"> Online Admission Link:</font> <a href="#"> admission.sadiaHostel.org.bd</a> ...
           <font color="green"> On-Hostel Admission: </font>Every day (10.00 am - 8.00 pm) ...
           <font color="green"> Hotline:</font> 01533850435 (10.00 am - 11.00 pm) </marquee>
    <hr>
       </div>
   

 <!-- navbar start -->
    <div class="navbar">
    
        <a href="http://127.0.0.1:5500/home.html#">Home</a>
       
    
    <!-- About start -->
    <div class="login">
        <a href="#">About </a>
        <div class="login_content">
            <a href="#">Chairman Sadia Hostel</a>
                <a href="#">Mission</a>
                <a href="#">Vision </a>
                <a href="#">Goal & scope</a>
        </div>
    </div>
     <!-- About End --> 
    
    
     
           <!-- Admission start -->
    <div class="login">
        <a href="#">Admission </a>
        <div class="login_content">
            <a href="#">Admission process details </a>
                <a href="http://127.0.0.1:5500/apply.html?name=Jewel+Rana&email=2019000000030%40seu.edu.bd&phone=01533850435&dob=2022-01-08&place=Dhaka&nationality=Bangladeshi&nid=21434563453&b=46453453413&Department=islam&Department=islam&gender=not+to+say&name=Jewel+Rana&phone=01533850435&name=Jewel+Rana&address=House-Bismillah+Tower%2C+Flat-H2%2C+Vashantek%2CMirpur&address=House-Bismillah+Tower%2C+Flat-H2%2C+Vashantek%2CMirpur" target="_blank">Apply Online</a>
                <a href="#">Fees </a>
                <a href="#">Contact </a>
        </div>
    </div>
     <!-- admission End --> 
         
       
     <a href="#">Available room/seat </a>
        
    
    
           <!-- Facilities start -->
           <div class="login">
            <a href="#">Facilities </a>
            <div class="login_content">
                    <a href="#">Gymnasium</a>
                    <a href="#">Library</a>
                    <a href="#">Ground </a>
                    <a href="#">Common room </a>
                    <a href="#">Canteen</a>
            </div>
        </div>
         <!-- Facilities End --> 
    
    
    
        <a href="https://www.google.com/maps/@23.8223854,90.3579972,13z" target="blank">Location </a>
         
    
    <!-- Chat with Sadia Hostel start -->
    <div class="login">
        <a href="#">Chat with Sadia Hostel </a>
        <div class="login_content">
                <a href="#">Login messenger</a>
                <a href="#">Continue as guest</a>
                 
        </div>
    </div>
     <!-- Chat with Sadia Hostel End --> 
    
    
  
 

   <!-- Contact start -->
   <div class="login">
    <a href="#">Contact</a>
    <div class="login_content">
         

        <div class="login2">
            <a href="#">Email</a>
            <div class="login_content2">
                <a href="#"target="_blank" >hostel.sadia@gmail.com</a>
                    
                    </div>
         </div>
    
         <div class="login2">
            <a href="#">Hotline</a>
            <div class="login_content2">
                <a href="#"target="_blank" >01533850435</a>
                     
                    </div>
         </div>

         <div class="login2">
            <a href="#">Whatsapp</a>
            <div class="login_content2">
                <a href=" #"target="_blank" >01983623034</a>
                    
                    </div>
         </div>

         <div class="login2">
            <a href="#">Facebook Page</a>
             
         </div>

    </div>
</div>
 <!-- Login End --> 









       <!-- Login start   -->
       <div class="login">
        <a href="#">Login</a>
        <div class="login_content">
            <a href="use.php" target="_blank">Administrator </a>
            <a href="http://127.0.0.1:5500/login.html?#"target="_blank">Student</a>
            <a href="http://127.0.0.1:5500/login.html?#"target="_blank">Hostel Secretery </a>
           

            <div class="login2">
                <a href="#">Registration</a>
                <div class="login_content2">
                    <a href="http://127.0.0.1:5500/registration.html"target="_blank" >As Administrator</a>
                        <a href="http://127.0.0.1:5500/registration.html"target="_blank">As Student</a>
                        <a href="http://127.0.0.1:5500/registration.html"target="_blank">As Hostel Secretery </a>
                        </div>
             </div>
        
        </div>
    </div>
     <!-- Login End --> 



   

     



 


     
     
<div class="random">
    <img src="" alt="" id="image">

    <script type="text/javascript">
      
      let image= document.getElementById('image');
      let images= ['5.jpg','6.jpg','3.jpg','8.jpg']
      setInterval(function(){

        let random= Math.floor(Math.random()*4);
        image.src = images[random];

      },800);


    </script>
</div>


    <div class="div div1">
        <br>
        <h1 class="h1">Admission</h1>
        <p class="p">We have customers coming from different backgrounds, cultures, and nationalities as well. Our customers are students, job-holder, tourist and others people. </p>
    </div>


    <div class="div div2">
        <br>
        <h1 class="h1">Hostel Fees</h1>
<p class="p">We offer affordable hostel fees for customer with the multiple installments to create convenience for students.</p>
    </div>

    <div class="div div3">
<br>
        <h1 class="h1">Special Waiver</h1>
        <p class="p">We are offering 60% special waiver for new customer only on admission fees. We are also giving 10% waiver only for students on monthly fee. </p>
    </div>



<div class="gap"></div>
<div class="offer">
    <br>

<br><br><br>
    <h1 class="h3">What we are giving Facilities?</h1>
<br><br>
</div>

 
<div class="diva div1">
    <br>
    <h1 class="h1">Library</h1>
    <p class="p">We have customers coming from different backgrounds, cultures, and nationalities as well. Our customers are students, job-holder, tourist and others people. </p>
    <hr><hr>

</div>


<div class="diva div2">
    <br>
    <h1 class="h1">Gymnasium</h1>

    <p class="p">We offer affordable hostel fees for customer with the multiple installments to create convenience for students.</p>
<hr><hr>
</div>
<div class="diva div3">
    <br>
    <h1 class="h1">Common Room</h1>

    <p class="p">We offer affordable hostel fees for customer with the multiple installments to create convenience for students.</p>
<hr><hr>
</div>
<div class="diva div4">
    <br>
    <h1 class="h1">Canteen</h1>

    <p class="p">We offer affordable hostel fees for customer with the multiple installments to create convenience for students.</p>
<hr><hr>
</div>
 

<div class="gap2"></div>

<div class="extradiv"></div>

 <div class="footer">
<hr><br>
Copyright &copy 2020 Sadia Hostel. All rights Reserved.
 </div>



</div>
 


</body>
</html>